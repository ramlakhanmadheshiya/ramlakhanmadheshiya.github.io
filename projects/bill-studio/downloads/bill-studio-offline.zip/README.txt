Bill Studio — offline & self-hosted package (build 38fe9f89ca, 2026-10-22)

1) Easiest: double-click Bill-Studio-offline.html. It runs in your browser with no internet.
   Use Google Chrome or Microsoft Edge (recommended), Firefox or Safari.
   Your data is stored inside that browser on this computer. Keep backups (Settings > Full backup).

2) For a whole office: copy the "web" folder to any web server (IIS, Apache, nginx, NAS, intranet).
   Open it over https:// (or http://localhost). It also installs as an app and works offline.

First sign-in: User ID 12345, password 67890 — change them in Settings right away.

Moving data between computers: Settings > Full backup on the old one, then Settings > Import > Replace
on the new one. To send only some days, use Export a period, then Import > Merge.
